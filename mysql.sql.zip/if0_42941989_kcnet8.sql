-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- 主机： sql204.infinityfree.com
-- 生成日期： 2026-10-11 09:25:55
-- 服务器版本： 11.4.13-MariaDB
-- PHP 版本： 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `if0_42941989_kcnet8`
--

-- --------------------------------------------------------

--
-- 表的结构 `lh_admin`
--

CREATE TABLE `lh_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `userpwd` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `token` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;

--
-- 转存表中的数据 `lh_admin`
--

INSERT INTO `lh_admin` (`id`, `username`, `userpwd`, `token`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '3f1faa669edebeeadfff49840a7d5c47'),
(2, 'jxs01', '21232f297a57a5a743894a0e4a801fc3', '');

-- --------------------------------------------------------

--
-- 表的结构 `lh_altplay`
--

CREATE TABLE `lh_altplay` (
  `id` int(11) NOT NULL,
  `thumb` varchar(80) NOT NULL,
  `ord` int(11) NOT NULL,
  `ctype` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;

--
-- 转存表中的数据 `lh_altplay`
--

INSERT INTO `lh_altplay` (`id`, `thumb`, `ord`, `ctype`) VALUES
(2, 'uploads/altplay/20260912202047_1789215647.png', 2, 0),
(3, 'uploads/altplay/20260912202056_1789215656.png', 3, 0),
(4, 'uploads/altplay/20260912202209_1789215729.png', 5, 0);

-- --------------------------------------------------------

--
-- 表的结构 `lh_cate`
--

CREATE TABLE `lh_cate` (
  `id` int(11) NOT NULL,
  `catename` varchar(60) NOT NULL,
  `ord` int(11) NOT NULL DEFAULT 1,
  `ctype` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- 转存表中的数据 `lh_cate`
--

INSERT INTO `lh_cate` (`id`, `catename`, `ord`, `ctype`) VALUES
(1, '基础型', 1, 1),
(2, '公告通知', 33, 2),
(3, '加强型', 1, 1),
(4, '高级型', 1, 1),
(6, '新闻动态', 1, 2);

-- --------------------------------------------------------

--
-- 表的结构 `lh_history`
--

CREATE TABLE `lh_history` (
  `id` int(11) NOT NULL,
  `hisdate` varchar(10) NOT NULL,
  `histitle` varchar(18) NOT NULL,
  `hiscon` varchar(200) NOT NULL,
  `istui` tinyint(4) NOT NULL DEFAULT 0,
  `hisord` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- 转存表中的数据 `lh_history`
--

INSERT INTO `lh_history` (`id`, `hisdate`, `histitle`, `hiscon`, `istui`, `hisord`) VALUES
(1, '2010', '公司成立', '2006年9月，全球互联网高速发展之际，武汉锐火计算机系统有限公司，主营软件开发、系统集成、网络安全服务。', 1, 2),
(2, '2006', '伤感情', '2006年9月，全球互联网高速发展之际，武汉锐火计算机系统有限公司，主营软件开发、系统集成、网络安全服务。', 1, 1),
(4, '2013', '公司持续发展', '奋进发展中', 1, 3);

-- --------------------------------------------------------

--
-- 表的结构 `lh_message`
--

CREATE TABLE `lh_message` (
  `id` int(11) NOT NULL COMMENT '主键',
  `username` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '真實姓名',
  `phone` varchar(11) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '郵箱',
  `email` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '用戶名',
  `msgcon` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `reply` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `ip` varchar(20) NOT NULL,
  `addtime` int(10) DEFAULT NULL COMMENT '添加時間'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;

--
-- 转存表中的数据 `lh_message`
--

INSERT INTO `lh_message` (`id`, `username`, `phone`, `email`, `msgcon`, `reply`, `ip`, `addtime`) VALUES
(119, '許漢宗', '', '0927066090', NULL, 'hhhhhhhh', '', 1603177432),
(120, '吳姿儀', NULL, '0925697258', '', 'bb', '', 1603177483),
(127, '張雪晴', '', '0955002726', NULL, 'cccccc', '', 1603178436),
(128, '陳建豪', '', '0933612152', NULL, 'NNNNNNNNNNN', '', 1603181876),
(1992, 'Jim Y', '1233423423', 'jim.young418@gmail.com', 'safsafsf', 'dddd11', '127.0.0.1', 1789138697),
(1994, 'Jim Y', '13333333', 'jim.young418@gmail.com', 'safsfeffdsgdserafxzvdfsf', '', '127.0.0.1', 1789480679),
(1995, 'Jim Y', '12222222222', 'jim.young418@gmail.com', 'safasfsafas', '', '127.0.0.1', 1789609877),
(1996, 'Jim Y', '13253252353', 'jim.young418@gmail.com', 'asfafaweffgsdgsd', NULL, '127.0.0.1', 1790003007);

-- --------------------------------------------------------

--
-- 表的结构 `lh_news`
--

CREATE TABLE `lh_news` (
  `id` int(11) NOT NULL,
  `title` varchar(80) NOT NULL,
  `subtitle` varchar(50) NOT NULL,
  `cate` tinyint(4) NOT NULL,
  `thumb` varchar(50) NOT NULL,
  `content` mediumtext NOT NULL,
  `ord` int(11) NOT NULL,
  `tui` tinyint(4) NOT NULL DEFAULT 0,
  `pubtime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;

--
-- 转存表中的数据 `lh_news`
--

INSERT INTO `lh_news` (`id`, `title`, `subtitle`, `cate`, `thumb`, `content`, `ord`, `tui`, `pubtime`) VALUES
(1, '2026氢能产业发展研讨会', '赋能工程机械绿色转型', 2, 'uploads/news/20261010195143_1791633103.png', '<p><br></p><p>2026氢能科技与产业发展战略研讨会暨成果报告会顺利举办，会议聚焦氢能装备核心技术攻关、产业化落地及场景应用，重点探讨氢能工程机械、燃料电池动力装备的研发与落地路径，展示了氢动力工程装备、氢能储能机械等最新技术成果，为传统工程机械绿色低碳转型、新能源装备产业化发展搭建重要协同平台。</p>', 3, 1, 1622179650),
(2, '南高齿子公司入选江苏先进级智能工厂', '南高精密机械制造智能化升级提速', 2, 'uploads/news/20261010194617_1791632777.png', '<p><br></p><p>江苏省工信厅公示2026年省级先进级智能工厂拟入选名单，南高齿集团旗下南京高精齿轮“基于精密制造的工业高效齿轮箱智能工厂”成功入围。该项目聚焦高端齿轮、传动设备的精密化、智能化生产，通过数字化产线改造、智能质检、全流程数据管控，大幅提升高端传动机械产品精度与产能，助力高端装备基础零部件国产化升级。</p>', 2, 1, 1622179899),
(3, '2026年8月工程机械销量大幅增长', '国内工程机械内需持续回暖', 6, 'uploads/news/20261010195105_1791633065.png', '<p><br></p><p>据中国工程机械工业协会统计数据显示，2026年8月国内主流企业各类装载机销量达10832台，同比增长14.7%，其中国内市场销量5421台，同比增长13.6%，电动装载机等新能源机型销量增速尤为突出，反映出基建施工、矿山开采、城乡基建更新等下游需求持续释放，工程机械终端市场活力持续恢复。</p>', 3, 1, 1622180046),
(5, '工程机械运行数据回暖', '工程机械运行数据回暖', 2, 'uploads/news/20261010194538_1791632738.png', '<p><br></p><p>中国工程机械工业协会发布最新行业指数快报，2026年9月工程机械主要产品月平均工作时长达80.7小时，同比增长3.32%、环比增长8.45%，其中挖掘机、装载机、起重机等主流设备开工数据全面回升，印证国内基建、工矿施工等终端市场需求持续复苏，行业景气度稳步上行。</p>', 1, 0, 1622514720),
(6, '华南重工矿用履带吊批量交付', '深耕工矿重载机械细分市场', 6, 'uploads/news/20261010195201_1791633121.png', '<p><br></p><p>华南重工自主研发的BYX-20矿用履带吊完成批量交付，先后入驻山西、贵州两大重点煤业集团。该设备针对矿山复杂恶劣工况优化升级，具备重载稳定、抗磨损、高适配性等特点，可满足矿山吊装、设备检修、矿区基建等多元作业需求，进一步壮大国产工矿重载机械产品矩阵，提升细分领域市场竞争力。</p>', 5, 0, 1622514896),
(7, '中联重科加速拓展海外矿机市场', '国际化营收持续增长', 6, 'uploads/news/20261010195224_1791633144.png', '<p><br></p><p>中联重科持续加码矿山机械海外布局，聚焦大型矿用挖掘机、破碎设备、掘进装备等核心产品，深耕东南亚、非洲、拉美等海外矿产资源开发市场。凭借高适配性产品、本地化服务体系，公司海外矿机订单持续攀升，国际业务营收占比稳步提升，推动国产大型矿山工程机械全球化布局提速。</p>', 6, 1, 1622514997),
(30, '机械行业两年发展目标', '机械行业两年发展目标', 2, 'uploads/news/20261010194521_1791632721.png', '<p>工信部、农业农村部、商务部等六部门联合印发《机械行业稳增长工作方案（2025—2026年）》，明确行业发展核心目标，提出2025至2026年机械行业营业收入年均增速稳定在3.5%左右，通过供需双向发力、产业链补短板、智能化升级、拓展海内外市场等举措，夯实机械行业国民经济支柱产业地位，助力制造业高质量发展。</p>', 1, 1, 1630296962),
(32, '徐工超大吨位履带起重机签约', '徐工赋能大型工程建设', 6, 'uploads/news/20261010194559_1791632759.png', '<p>徐工4200吨级超大吨位履带起重机成功签约中国化学工程集团，该设备为国内高端重型工程机械标杆产品，具备大载荷、高稳定性、适配复杂工况等优势，将重点服务于大型石化、新能源基建、重工吊装等重大工程，标志着国产超大吨位起重装备持续替代进口，高端工程装备国产化能力再获突破。</p>', 2, 1, 1790347075),
(33, '凌宇机械大型节能干燥设备交付', '通用机械节能技术迭代升级', 6, 'uploads/news/20261010195524_1791633324.png', '<p><br></p><p>广东凌宇研发的四套1600m³零气耗压缩热干燥设备正式完成交付。该通用机械装备突破传统干燥设备高能耗短板，实现零气耗、低能耗、高效率运行，广泛应用于工业气源净化、化工、制造等领域，彰显国内通用机械设备在节能降耗、技术创新领域的迭代成果，助力工业生产绿色降本。</p>', 5, 0, 1791633324),
(34, '机械行业加速AI赋能', '能制造全流程升级全面推进', 6, 'uploads/news/20261011121940_1791692380.png', '<p>当前国内机械行业智能化改造进入深度落地阶段，行业聚焦AI与机械装备、生产流程的深度融合，重点推进智能产线改造、工业垂直模型应用、智能质检、无人作业装备研发等核心工作。各地制造企业持续加大智能装备研发投入，依托产学研协同攻关，突破智能制造关键技术，推动机械行业从传统制造向数字化、智能化、高端化全面转型。</p>', 1, 0, 1791692380);

-- --------------------------------------------------------

--
-- 表的结构 `lh_product`
--

CREATE TABLE `lh_product` (
  `id` int(11) NOT NULL,
  `proname` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `subtitle` varchar(60) NOT NULL,
  `intro` text NOT NULL,
  `thumb` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `content` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `cate` int(11) NOT NULL,
  `tui` tinyint(4) DEFAULT 0,
  `ord` int(11) NOT NULL DEFAULT 0,
  `addtime` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;

--
-- 转存表中的数据 `lh_product`
--

INSERT INTO `lh_product` (`id`, `proname`, `subtitle`, `intro`, `thumb`, `content`, `cate`, `tui`, `ord`, `addtime`) VALUES
(6, '加强型产品B', '加强型产品B', '<p>加强型产品B</p><p>加强型产品B</p><p>加强型产品B</p>', 'uploads/product/20260930162632_1790756792.png', '<p><img src=\"/public/upload/20200917/1600342758522299.jpg\" alt=\"\" data-href=\"\" style=\"\"/>加强型产品B加强型产品B加强型产品B加强型产品B加强型产品B加强型产品B</p><p><img src=\"/public/upload/20200917/1600342756694725.jpg\" alt=\"\" data-href=\"\" style=\"\"/></p><p><img src=\"/public/upload/20200917/1600342756380013.jpg\" alt=\"\" data-href=\"\" style=\"\"/></p><p><img src=\"/public/upload/20200917/1600342757753822.jpg\" alt=\"\" data-href=\"\" style=\"\"/></p><p><img src=\"/public/upload/20200917/1600342757948132.jpg\" alt=\"\" data-href=\"\" style=\"\"/></p><p><img src=\"/public/upload/20201019/1603109559544916.jpg\" alt=\"\" data-href=\"\" style=\"\"/></p><p> </p>', 3, 0, 0, 1600308518),
(8, '加强型产品D', '加强型产品D', '<p>加强型产品D</p><p>加强型产品D</p><p>加强型产品D</p>', 'uploads/product/20261010201047_1791634247.png', '<p>加强型产品D加强型产品D加强型产品D加强型产品D加强型产品D加强型产品D</p><p><img src=\"http://iloveme.com.tw/public/upload/20200919/1600491014771278.jpg\" alt=\"\" data-href=\"\" style=\"\"/></p><p><img src=\"/public/upload/20200919/1600491013465560.jpg\" alt=\"\" data-href=\"\" style=\"\"/></p><p><img src=\"/public/upload/20200919/1600491013732014.jpg\" alt=\"\" data-href=\"\" style=\"\"/></p><p><img src=\"/public/upload/20201019/1603109368684911.jpg\" alt=\"\" data-href=\"\" style=\"\"/></p><p><br></p>', 3, 1, 1, 1600341213),
(9, '基础型产品B', '基础型产品B', '<p><span style=\"font-size: 16px;\"><strong>产品参数表</strong></span></p><p>长：6.8米</p><p>宽：6.8米</p><p>高：6.8米</p>', 'uploads/product/20260930162041_1790756441.png', '<p><img src=\"/public/upload/20200919/1600487763672330.jpg\" alt=\"\" data-href=\"\" style=\"\"/>基础型产品B基础型产品B基础型产品B基础型产品B</p><p><img src=\"http://iloveme.com.tw/public/upload/20200919/1600487766838401.jpg\" alt=\"\" data-href=\"\" style=\"\"/></p><p><img src=\"http://iloveme.com.tw/public/upload/20200919/1600487765749323.jpg\" alt=\"\" data-href=\"\" style=\"\"/></p><p><img src=\"/public/upload/20200919/1600487764914524.jpg\" alt=\"\" data-href=\"\" style=\"\"/></p><p><img src=\"/public/upload/20200919/1600487764568190.jpg\" alt=\"\" data-href=\"\" style=\"\"/></p><p><img src=\"/public/upload/20201019/1603109196320102.jpg\" alt=\"\" data-href=\"\" style=\"\"/></p>', 1, 0, 1, 1600341280),
(49, '加强型产品A', '加强型产品A', '<p>加强型产品A</p><p>加强型产品A</p><p>加强型产品A</p>', 'uploads/product/20260930162152_1790756512.png', '<p>加强型产品A加强型产品A加强型产品A</p>', 3, 0, 0, 1666951437),
(50, '加强型产品C', '加强型产品C', '<p><span style=\"color: rgb(96, 98, 102); background-color: rgb(255, 255, 255); font-size: 14px;\">加强型产品C</span></p><p><span style=\"color: rgb(96, 98, 102); background-color: rgb(255, 255, 255); font-size: 14px;\">加强型产品C</span></p><p><span style=\"color: rgb(96, 98, 102); background-color: rgb(255, 255, 255); font-size: 14px;\">加强型产品C</span></p>', 'uploads/product/20260930163135_1790757095.png', '<p><span style=\"color: rgb(96, 98, 102); background-color: rgb(255, 255, 255); font-size: 14px;\">加强型产品C加强型产品C加强型产品C加强型产品C加强型产品C加强型产品C加强型产品C加强型产品C</span></p>', 3, 0, 1, 1667013611),
(51, '基础型产品F', '基础型产品F', '<p>基础型产品F</p><p>基础型产品F</p><p>基础型产品F</p>', 'uploads/product/20261010200847_1791634127.png', '<p>基础型产品F基础型产品F基础型产品F基础型产品F基础型产品F基础型产品F基础型产品F</p>', 1, 0, 2, 1667014227),
(56, '基础型产品A', '基础型产品AA', '<p>基础型产品A</p><p>基础型产品A</p><p>基础型产品A</p>', 'uploads/product/20260930161550_1790756150.png', '<p>基础型产品A基础型产品A基础型产品A基础型产品A基础型产品A基础型产品A基础型产品A</p>', 1, 1, 1, 1667223668),
(59, '基础型产品E', '基础型产品E', '<p>基础型产品E</p><p>基础型产品E</p><p>基础型产品E</p>', 'uploads/product/20261010200824_1791634104.png', '<p>基础型产品E基础型产品E基础型产品E基础型产品E基础型产品E</p>', 1, 0, 2, 1667389415),
(63, '加强型产品C', '加强型产品C', '<p>加强型产品C</p><p>加强型产品C</p><p>加强型产品C</p>', 'uploads/product/20261010201020_1791634220.png', '<p>加强型产品C加强型产品C加强型产品C加强型产品C加强型产品C</p>', 3, 0, 1, 1667469922),
(64, '基础型产品D', '基础型产品D', '<p>基础型产品D</p><p>基础型产品D</p><p>基础型产品D</p>', 'uploads/product/20261010200656_1791634016.png', '<p>基础型产品D基础型产品D基础型产品D基础型产品D</p>', 1, 1, 1, 1789265129),
(65, '加强型产品E', '加强型产品E', '<p>加强型产品E</p><p>加强型产品E</p><p>加强型产品E</p>', 'uploads/product/20261011193115_1791718275.png', '<p>加强型产品E加强型产品E加强型产品E加强型产品E加强型产品E加强型产品E加强型产品E加强型产品E</p>', 3, 1, 2, 1789266430),
(66, '基础型产品B', '基础型产品B', '<p>基础型产品B</p><p>基础型产品B</p><p>基础型产品B</p>', 'uploads/product/20260930161816_1790756296.png', '<p>基础型产品B基础型产品B基础型产品B基础型产品B基础型产品B基础型产品B基础型产品B基础型产品B基础型产品B</p>', 1, 1, 1, 1789376993),
(67, '高级型产品A', '高级型产品A', '<p>参数：123</p><p>速度：231</p><p>转速：333</p>', 'uploads/product/20260930163742_1790757462.png', '<p>高级型产品A高级型产品A高级型产品A</p>', 4, 1, 7, 1790342705);

-- --------------------------------------------------------

--
-- 表的结构 `lh_propic`
--

CREATE TABLE `lh_propic` (
  `id` int(11) NOT NULL,
  `pic` varchar(50) NOT NULL,
  `ord` int(11) NOT NULL,
  `proid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;

--
-- 转存表中的数据 `lh_propic`
--

INSERT INTO `lh_propic` (`id`, `pic`, `ord`, `proid`) VALUES
(2, 'uploads/product/20260911001452_1789056892.jpg', 2, 51),
(3, 'uploads/product/20260911200112_1789128072.jpg', 1, 51),
(4, 'uploads/product/20260911200127_1789128087.jpg', 0, 51),
(5, 'uploads/product/20261010201228_1791634348.png', 0, 49),
(6, 'uploads/product/20261010201255_1791634375.png', 0, 6),
(8, 'uploads/product/20261010201320_1791634400.png', 0, 66),
(9, 'uploads/product/20261010201352_1791634432.png', 0, 64),
(10, 'uploads/product/20261010201413_1791634453.png', 0, 63),
(11, 'uploads/product/20261010201436_1791634476.png', 0, 56),
(12, 'uploads/product/20261010201502_1791634502.png', 0, 9),
(13, 'uploads/product/20261010201534_1791634534.png', 0, 8),
(14, 'uploads/product/20261010201535_1791634535.png', 0, 8),
(15, 'uploads/product/20261010201559_1791634559.png', 0, 65),
(16, 'uploads/product/20261010201643_1791634603.png', 0, 59),
(17, 'uploads/product/20261010201645_1791634605.png', 0, 59),
(18, 'uploads/product/20261010201730_1791634650.png', 0, 67);

-- --------------------------------------------------------

--
-- 表的结构 `lh_sys`
--

CREATE TABLE `lh_sys` (
  `id` int(11) NOT NULL,
  `webkey` varchar(30) NOT NULL,
  `webcon` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- 转存表中的数据 `lh_sys`
--

INSERT INTO `lh_sys` (`id`, `webkey`, `webcon`) VALUES
(1, 'AboutUs', '<p>test<img src=\"/public/uploads/wangeditor/20260915131528_1789478128.png\" alt=\"\" data-href=\"\" style=\"\"/><img src=\"/uploads/wangeditor/20260925212110_1790342470.jpg\" alt=\"\" data-href=\"\" style=\"\"/>😈</p>'),
(2, 'ContactUs', '<p><img src=\"/uploads/wangeditor/20260915114515_856744.jpg\" alt=\"20260911200127_1789128087.jpg\" data-href=\"\" style=\"width: 146.00px;height: 146.00px;\"/><img src=\"/uploads/wangeditor/20260914222125_1789395685.jpg\" alt=\"\" data-href=\"\" style=\"\"/><img src=\"/uploads/ueditor/image/20260906/20260906131421_904778.png\" alt=\"email2.png\" data-href=\"\" style=\"\"/><img src=\"/uploads/ueditor/image/20260915/20260915113617_937909.jpg\" alt=\"20260906111030_1788664230.jpg\" data-href=\"\" style=\"\"/></p>'),
(3, 'ABExt', '专业技术团队，10年行业开发经验22'),
(4, 'CTExt', '我们将以无限热忱之态度与服务对待每一位客户11'),
(5, 'ProExt', '完善的设计及持续的改进让我们更强大22'),
(6, 'NewsExt', '专业技术团队，10年行业开发经验66'),
(7, 'MSGExt', '关于我们测试99999'),
(8, 'DevlpExt', '记录我们的成长与蜕变');

-- --------------------------------------------------------

--
-- 表的结构 `lh_web`
--

CREATE TABLE `lh_web` (
  `id` int(11) NOT NULL,
  `webtitle` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `weburl` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `webkeyword` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `webdes` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `zhuce_juanqty` int(11) NOT NULL DEFAULT 3 COMMENT '會員註冊。送n張優惠券',
  `tuijian_juanqty` int(11) NOT NULL DEFAULT 3 COMMENT '分享者分享出去。被分享者註冊，分享者可以拿n張優惠券',
  `youxian_days` int(11) NOT NULL DEFAULT 30 COMMENT '贈送的優惠券有限天數',
  `youhuijuan_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '優惠券名稱',
  `yunfei` int(11) NOT NULL DEFAULT 90,
  `mianyunmoney` int(11) NOT NULL DEFAULT 1500,
  `taxrate` double NOT NULL DEFAULT 0,
  `anzhi_type` int(11) NOT NULL COMMENT '太陽線安置方式'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;

--
-- 转存表中的数据 `lh_web`
--

INSERT INTO `lh_web` (`id`, `webtitle`, `weburl`, `webkeyword`, `webdes`, `zhuce_juanqty`, `tuijian_juanqty`, `youxian_days`, `youhuijuan_name`, `yunfei`, `mianyunmoney`, `taxrate`, `anzhi_type`) VALUES
(1, '愛樂魅-i love me', 'https://iloveme.com.tw/', '愛樂魅,i love me,膠原蛋白胜肽,煥妍亮白膠原胜肽', '愛樂魅-i love me', 1, 1, 30, '店長價購物優惠券', 100, 5000, 11.92, 2);

-- --------------------------------------------------------

--
-- 表的结构 `lh_webpage`
--

CREATE TABLE `lh_webpage` (
  `id` int(11) NOT NULL COMMENT '主键',
  `name` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '菜單名稱',
  `code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '菜單代碼',
  `orderId` int(11) DEFAULT NULL COMMENT '排序',
  `firstId` int(11) DEFAULT NULL COMMENT '第一層',
  `secondId` int(11) DEFAULT NULL COMMENT '第二層',
  `thirdId` int(11) DEFAULT NULL COMMENT '第三層',
  `des` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '菜單描述',
  `filepath` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '菜單 URL',
  `isshow` int(11) DEFAULT NULL COMMENT '是否顯示'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;

--
-- 转存表中的数据 `lh_webpage`
--

INSERT INTO `lh_webpage` (`id`, `name`, `code`, `orderId`, `firstId`, `secondId`, `thirdId`, `des`, `filepath`, `isshow`) VALUES
(1, '基礎管理', 'base_code_mgr', 1, 1, 0, 0, '', NULL, 1),
(2, '網站信息', 'news_mgr', 2, 2, 0, 0, NULL, NULL, 0),
(3, '廣告管理', 'guanggao_mgr', 1000, 15, 0, 0, NULL, NULL, 0),
(4, '公告消息', 'xueyuan_mgr', 10, 18, 0, 0, NULL, NULL, 0),
(5, '服務項目管理', 'proPinPaimgr_mgr', 11, 4, 0, 0, NULL, NULL, 0),
(6, '服务内容', 'changshang_mgr', 4, 14, 0, 0, '0', NULL, 0),
(7, '產品類別管理', 'htadmin_mgr', 5, 5, 0, 0, NULL, NULL, 0),
(8, '屬性管理', 'shuxing_mgr', 8, 13, 0, 0, '', '', 0),
(9, '720度圖片管理', 'products_mgr', 9, 6, 0, 0, NULL, NULL, 1),
(10, '會員管理', 'users_mgr', 10, 3, 0, 0, NULL, NULL, 1),
(11, '課程管理', 'huishouxiang_mgr', 11, 10, 0, 0, NULL, NULL, 0),
(12, '制度管理', 'zhidu_mgr', 12, 16, 0, 0, NULL, NULL, 0),
(13, '訂單管理', 'orders_mgr', 13, 7, 0, 0, NULL, NULL, 0),
(14, '獎金管理', 'jiangjin_mgr', 14, 8, 0, 0, NULL, NULL, 0),
(15, '權限組管理', 'rolesets_mgr', 15, 11, 0, 0, NULL, NULL, 0),
(16, '後臺管理者管理', 'htadmin_mgr', 16, 12, 0, 0, NULL, NULL, 0),
(17, '日誌管理', 'logs_mgr', 17, 9, 0, 0, NULL, NULL, 0),
(18, '新增權限組', 'addrole', 1, 11, 1, 0, NULL, 'add_role.php', 1),
(19, '權限組列表', 'list_role', 2, 11, 2, 0, NULL, 'list_role.php', 1),
(20, '權限組頁面配置', 'rolepageset', 3, 11, 3, 0, NULL, 'admin_rolepages.php', 1),
(21, '權限組操作配置', 'rolepage_dzset', 4, 11, 4, 0, NULL, 'admin_rolepagesoper.php', 0),
(22, '部門管理', 'list_bumen', 2, 12, 1, 0, NULL, 'list_bumen.php', 1),
(23, '新增管理者', 'add_admin', 3, 12, 2, 0, NULL, 'add_admin.php', 1),
(24, '管理者列表', 'list_admin', 4, 12, 3, 0, NULL, 'list_admin.php', 1),
(25, '新增會員', 'add_users', 1, 3, 1, 0, NULL, 'user/add', 1),
(26, '會員列表', 'list_users', 2, 3, 2, 0, NULL, 'user/list', 1),
(27, '會員升級套餐配置', 'add_shengjicanshu', 1, 16, 3, 0, NULL, 'user/add_canshuset.php', 0),
(28, '會員獎金列表', 'user_jiangjin', 1, 8, 4, 0, NULL, 'jiangjin/list_jiangjin.php', 0),
(31, '新增720度圖片', 'add_pro', 1, 6, 1, 0, NULL, 'product/proadd', 1),
(32, '720度圖片列表', 'list_pro', 2, 6, 2, 0, NULL, 'product/prolist', 1),
(35, '系統配置', 'add_changshang', 1, 1, 1, 0, NULL, 'Configweb/index', 1),
(36, '關於我們', 'list_changshang', 3, 2, 4, 0, NULL, 'Configweb/reginfo/1', 1),
(39, '新增部門', 'add_bumen', 1, 12, 1, 0, NULL, 'add_bumen.php', 1),
(42, '展望與未來', 'add_shouhuofw', 1, 2, 3, 0, NULL, 'Configweb/reginfo/5', 1),
(43, '人員招募', 'add_fuwutiaokuan', 4, 2, 4, 0, NULL, 'Configweb/reginfo/2', 1),
(44, '門市資訊', 'add_zhucetiaokuan', 4, 1, 4, 0, NULL, 'Configweb/reginfo/7', 0),
(45, '經營項目', 'add_syspeizhi', 1, 1, 1, NULL, NULL, 'Configweb/reginfo/4', 0),
(46, '新增廣告', 'add_ganggao', 1, 15, 1, 0, NULL, 'advertisement/addad', 1),
(47, '廣告列表', 'list_guanggao', 2, 15, 2, 0, NULL, 'advertisement/list', 1),
(48, '加碼獎對等獎配置', 'add_jiamajiang', 3, 16, 6, NULL, NULL, 'user/add_jiamajiang.php', 1),
(49, '月分紅配置', 'add_yuefenhong', 4, 16, 7, 0, NULL, 'user/add_yuefenhong.php', 1),
(50, '消費獎金配置', 'add_xiaofeijiangjin', 5, 16, 8, 0, NULL, 'user/add_xiaofeijiangjin.php', 1),
(51, '種子樹值配置', 'add_treezhi', 6, 16, 9, 0, NULL, 'user/add_treezhi.php', 1),
(52, '推薦獎金比例配置', 'add_tuijianjiangjin', 7, 16, 10, 0, NULL, 'user/add_tuijianjiangjin.php', 1),
(54, '訂單列表', 'list_orders', 1, 7, 1, 0, NULL, 'orders/list', 1),
(55, '退貨申請列表', 'list_tuihuo', 2, 7, 2, 0, NULL, 'orderback/list', 0),
(56, '新增新闻类别', 'add_libao', 1, 18, 1, 0, NULL, 'newscategory/addcategory', 0),
(57, '新闻类别列表', 'list_libao', 2, 18, 2, 0, NULL, 'newscategory/categorylist', 0),
(58, '修改密码', 'registerinfo', 2, 1, 2, 0, NULL, 'Configweb/updatepwd', 1),
(59, '訂單獎金統計', 'list_sysjiangjin', 2, 8, 3, 0, NULL, 'jiangjin/list_sysjiangjin.php', 0),
(60, '作貨分紅', 'list_quanqiufh', 4, 8, 1, 0, NULL, 'jiangjin/list_quanqiufh.php', 1),
(61, '修改推薦人', 'list_tuijianren', 3, 3, 3, 0, NULL, 'user/list_tuijianren.php', 0),
(62, '會員推薦結構圖', 'list_treelist', 4, 3, 3, 0, NULL, 'user/list_treelist.php', 0),
(63, '訂單獎金明細', 'list_orderjiangjin', 3, 8, 1, 0, NULL, 'jiangjin/list_orderjiangjin.php', 1),
(64, '服务客户编辑区', 'add_lianluowomen', 6, 2, 1, 0, NULL, 'Configweb/reginfo/3\n', 0),
(66, '添加公告', 'add_shiping', 1, 18, 1, 0, NULL, 'news/proadd', 1),
(67, '公告列表', 'list_shiping', 2, 18, 1, 0, NULL, 'news/prolist', 1),
(68, '提現申請訂單', 'list_tixiansq', 3, 7, 1, 0, NULL, 'order/list_tixiansq.php', 0),
(69, '日誌記錄', 'list_rizhi', 1, 9, 1, 0, NULL, 'list_rizhi.php', 1),
(70, '會員分紅調整', 'list_jiangjin_tz', 5, 3, 3, 0, NULL, 'user/list_jiangjin_tz.php', 0),
(71, '會員升級日誌', 'list_ushengji', 6, 3, 6, 0, NULL, 'user/list_ushengji.php', 0),
(72, '作貨分紅記錄', 'list_quanqiutj', 5, 8, 8, 0, NULL, 'jiangjin/list_quanqiutj.php', 1),
(74, '首頁_產品特色', 'list_wuliucoms', 3, 1, 3, 0, NULL, 'Configweb/reginfo/4', 0),
(75, '新增客戶類別', 'add_ysqtiaokuan', 7, 2, 7, 0, NULL, 'fwcategory/addcategory', 0),
(78, '加盟列表', 'list_jiameng', 7, 3, 6, 0, NULL, 'user/list_jiameng.php', 0),
(79, '首頁_編輯區', 'list_banks', 4, 1, 4, 0, NULL, 'Configweb/reginfo/1', 0),
(80, '商品屬性類型', 'list_goods_type', 3, 13, 3, NULL, NULL, 'shuxing/list_goods_type.php', 0),
(81, '添加屬性類型', 'add_goods_type', 4, 13, 3, NULL, NULL, 'shuxing/add_goods_type.php', 1),
(82, '會員等級管理', 'userrank_list', 4, 3, 3, 0, NULL, 'user/userrank_list.php', 0),
(83, '客戶類別列表', 'add_news', 7, 2, 2, 0, NULL, 'fwcategory/categorylist', 0),
(84, '新增服务客户', 'list_news', 8, 2, 3, NULL, NULL, 'video/add', 0),
(85, '營業業績分紅', 'yinye_list', 7, 8, 5, 1, '0', 'jiangjin/yinye_list.php', 1),
(86, '營業業績分紅記錄', 'yinyelog_list', 8, 8, 6, 1, NULL, 'jiangjin/yinyelog_list.php', 0),
(87, '服务客户列表', 'abouttaoyi', 2, 2, 2, NULL, NULL, 'video/list', 0),
(88, '合作夥伴', 'abouttaoyi_sub', 6, 1, 4, NULL, NULL, 'Configweb/reginfo/2\r\n', 0),
(89, '報名列表', 'list_baoming', 3, 10, 3, 0, NULL, 'baoming/list', 1),
(90, '聯絡我們', 'jionin', 1, 1, 4, 0, NULL, 'Configweb/reginfo/3', 0),
(91, '新增聯絡我們', 'add_newslist', 9, 100, 4, 0, NULL, 'newslist/add', 1),
(92, '聯絡我們列表', 'list_newslist', 10, 100, 4, 0, NULL, 'newslist/list', 1),
(93, '聯絡我們', 'bbs', 100, 100, 0, 0, NULL, '', 0),
(94, '留言列表', 'bbs', 100, 100, 1, 0, NULL, 'bbs/list', 1);

--
-- 转储表的索引
--

--
-- 表的索引 `lh_admin`
--
ALTER TABLE `lh_admin`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `lh_altplay`
--
ALTER TABLE `lh_altplay`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `lh_cate`
--
ALTER TABLE `lh_cate`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `lh_history`
--
ALTER TABLE `lh_history`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `lh_message`
--
ALTER TABLE `lh_message`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `lh_news`
--
ALTER TABLE `lh_news`
  ADD UNIQUE KEY `id` (`id`);

--
-- 表的索引 `lh_product`
--
ALTER TABLE `lh_product`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `lh_propic`
--
ALTER TABLE `lh_propic`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `lh_sys`
--
ALTER TABLE `lh_sys`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `lh_web`
--
ALTER TABLE `lh_web`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `lh_webpage`
--
ALTER TABLE `lh_webpage`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `lh_admin`
--
ALTER TABLE `lh_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `lh_altplay`
--
ALTER TABLE `lh_altplay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- 使用表AUTO_INCREMENT `lh_cate`
--
ALTER TABLE `lh_cate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 使用表AUTO_INCREMENT `lh_history`
--
ALTER TABLE `lh_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- 使用表AUTO_INCREMENT `lh_message`
--
ALTER TABLE `lh_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键', AUTO_INCREMENT=1997;

--
-- 使用表AUTO_INCREMENT `lh_news`
--
ALTER TABLE `lh_news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- 使用表AUTO_INCREMENT `lh_product`
--
ALTER TABLE `lh_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- 使用表AUTO_INCREMENT `lh_propic`
--
ALTER TABLE `lh_propic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- 使用表AUTO_INCREMENT `lh_sys`
--
ALTER TABLE `lh_sys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 使用表AUTO_INCREMENT `lh_webpage`
--
ALTER TABLE `lh_webpage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键', AUTO_INCREMENT=96;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
